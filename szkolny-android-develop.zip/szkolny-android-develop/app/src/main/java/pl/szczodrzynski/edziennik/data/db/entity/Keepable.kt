/*
 * Copyright (c) Kuba Szczodrzyński 2020-3-30.
 */

package pl.szczodrzynski.edziennik.data.db.entity

abstract class Keepable {
    var keep: Boolean = true
}
