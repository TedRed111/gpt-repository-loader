package pl.szczodrzynski.edziennik.core.work

class AppManagerDetectedEvent(val failedWorkTimestamps: List<Long>)
