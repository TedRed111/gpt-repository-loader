/*
 * Copyright (c) Kuba Szczodrzyński 2019-10-1.
 */

package pl.szczodrzynski.edziennik.data.api.events.requests

class TaskCancelRequest(val taskId: Int)
