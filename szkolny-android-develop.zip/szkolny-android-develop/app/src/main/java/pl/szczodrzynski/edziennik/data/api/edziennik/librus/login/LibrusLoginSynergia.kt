/*
 * Copyright (c) Kuba Szczodrzyński 2019-9-20.
 */

package pl.szczodrzynski.edziennik.data.api.edziennik.librus.login

import com.google.gson.JsonObject
import im.wangchao.mhttp.Request
import im.wangchao.mhttp.Response
import im.wangchao.mhttp.callback.TextCallbackHandler
import pl.szczodrzynski.edziennik.data.api.*
import pl.szczodrzynski.edziennik.data.api.edziennik.librus.DataLibrus
import pl.szczodrzynski.edziennik.data.api.edziennik.librus.data.LibrusApi
import pl.szczodrzynski.edziennik.data.api.models.ApiError
import pl.szczodrzynski.edziennik.data.enums.LoginMethod
import pl.szczodrzynski.edziennik.ext.getString
import pl.szczodrzynski.edziennik.ext.getUnixDate
import timber.log.Timber
import java.net.HttpURLConnection

class LibrusLoginSynergia(override val data: DataLibrus, val onSuccess: () -> Unit) : LibrusApi(data, null) {
    companion object {
        private const val TAG = "LoginLibrusSynergia"
    }

    init { run {
        if (data.profile == null) {
            data.error(ApiError(TAG, ERROR_PROFILE_MISSING))
            return@run
        }

        if (data.isSynergiaLoginValid()) {
            data.app.cookieJar.set("synergia.librus.pl", "DZIENNIKSID", data.synergiaSessionId)
            onSuccess()
        }
        else {
            data.app.cookieJar.clear("synergia.librus.pl")
            if (data.loginMethods.contains(LoginMethod.LIBRUS_API)) {
                loginWithApi()
            }
            else if (data.apiLogin != null && data.apiPassword != null && false) {
                loginWithCredentials()
            }
            else {
                data.error(ApiError(TAG, ERROR_LOGIN_DATA_MISSING))
            }
        }
    }}

    /**
     * HTML form-based login method. Uses a Synergia login and password.
     */
    private fun loginWithCredentials() {

    }

    /**
     * A login method using the Synergia API (AutoLoginToken endpoint).
     */
    private fun loginWithApi() {
        Timber.d("Request: Librus/Login/Synergia - $LIBRUS_API_URL/AutoLoginToken")

        val onSuccess = { json: JsonObject ->
            loginWithToken(json.getString("Token"))
        }

        apiGet(TAG, "AutoLoginToken", POST, onSuccess = onSuccess)
    }

    private fun loginWithToken(token: String?) {
        if (token == null) {
            data.error(ApiError(TAG, ERROR_LOGIN_LIBRUS_SYNERGIA_NO_TOKEN))
            return
        }

        Timber.d("Request: Librus/Login/Synergia - " + LIBRUS_SYNERGIA_TOKEN_LOGIN_URL.replace("TOKEN", token) + "/uczen/widok/centrum_powiadomien")

        val callback = object : TextCallbackHandler() {
            override fun onSuccess(json: String?, response: Response?) {
                val location = response?.headers()?.get("Location")
                if (location?.endsWith("przerwa_techniczna") == true) {
                    data.error(ApiError(TAG, ERROR_LIBRUS_SYNERGIA_MAINTENANCE)
                            .withApiResponse(json)
                            .withResponse(response))
                    return
                }

                if (location?.endsWith("centrum_powiadomien") == true) {
                    val sessionId = data.app.cookieJar.get("synergia.librus.pl", "DZIENNIKSID")
                    if (sessionId == null) {
                        data.error(ApiError(TAG, ERROR_LOGIN_LIBRUS_SYNERGIA_NO_SESSION_ID)
                                .withResponse(response)
                                .withApiResponse(json))
                        return
                    }
                    data.synergiaSessionId = sessionId
                    data.synergiaSessionIdExpiryTime = response.getUnixDate() + 45 * 60 /* 45min */
                    onSuccess()
                }
                else {
                    data.error(ApiError(TAG, ERROR_LOGIN_LIBRUS_SYNERGIA_TOKEN_INVALID)
                            .withResponse(response)
                            .withApiResponse(json))
                }
            }

            override fun onFailure(response: Response?, throwable: Throwable?) {
                data.error(ApiError(TAG, ERROR_REQUEST_FAILURE)
                        .withResponse(response)
                        .withThrowable(throwable))
            }
        }

        data.app.cookieJar.clear("synergia.librus.pl")
        Request.builder()
                .url(LIBRUS_SYNERGIA_TOKEN_LOGIN_URL.replace("TOKEN", token) + "/uczen/widok/centrum_powiadomien")
                .userAgent(LIBRUS_USER_AGENT)
                .get()
                .allowErrorCode(HttpURLConnection.HTTP_BAD_REQUEST)
                .allowErrorCode(HttpURLConnection.HTTP_FORBIDDEN)
                .allowErrorCode(HttpURLConnection.HTTP_UNAUTHORIZED)
                .callback(callback)
                .withClient(data.app.httpLazy)
                .build()
                .enqueue()
    }
}
