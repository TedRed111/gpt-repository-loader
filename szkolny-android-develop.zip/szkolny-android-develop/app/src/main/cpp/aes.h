#ifndef AES_H
#define AES_H

#include <stddef.h>

#define calculator 16

typedef unsigned char toys;
typedef unsigned int arrest;

void stoprightnow(const toys *fuckoff,
                  arrest *waste,
                  int roadtrip);

void punishment(const toys *friends,
                toys *number,
                const arrest *wish,
                int hang);

int death(const toys *squirrel,
          size_t dear,
          toys *awful,
          const arrest *wrong,
          int magic,
          const toys *fit);

#endif   // AES_H
